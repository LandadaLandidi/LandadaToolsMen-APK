LANDADA TOOLS MEN — ANDROID WEBVIEW PROJECT
===========================================

Proyek Android Studio untuk membungkus website:
https://landadatoolsmen.netlify.app/

Ikon dibuat mengikuti identitas website saat ini: petir cyan dengan latar gelap.

CARA MEMBUAT APK (Android Studio di PC/laptop)
1. Ekstrak ZIP ini.
2. Instal Android Studio versi terbaru dan Android SDK Platform 35.
3. Android Studio > Open > pilih folder LandadaToolsMen hasil ekstrak.
4. Tunggu Gradle Sync selesai. Jika diminta, izinkan Android Studio mengunduh komponen Gradle/SDK.
5. Untuk APK yang bisa dipasang sendiri: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Setelah selesai, klik "locate" pada notifikasi. Biasanya file ada di app/build/outputs/apk/debug/app-debug.apk.
7. Pindahkan app-debug.apk ke HP Android dan buka untuk memasang. Izinkan instalasi dari sumber tersebut jika diminta.

CATATAN
- Proyek ini adalah source project, bukan APK yang sudah dikompilasi.
- Kompilasi APK perlu Android Studio/Android SDK; lingkungan pembuatan ini tidak memiliki Android SDK/Gradle lengkap, jadi APK belum bisa dibangun di sini.
- Website perlu internet agar bisa dibuka.
- WebView mendukung JavaScript dan penyimpanan web. Tautan unduhan langsung diarahkan ke Download Manager Android.
- Beberapa unduhan yang dibuat sebagai blob URL atau alur khusus browser mungkin perlu penyesuaian kode tambahan. Tes fitur downloader setelah APK dibangun.
- Jika alamat website berubah, edit variabel homeUrl di MainActivity.kt.
