plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.landadatoolsmen.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.landadatoolsmen.app"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
